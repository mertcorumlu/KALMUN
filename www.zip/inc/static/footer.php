<?php
/**
 * Created by PhpStorm.
 * User: MERT
 * Date: 07/05/2018
 * Time: 01:38
 */

?>
<!-- ### $App Screen Footer ### -->
<footer class="bdT ta-c p-10 fsz-sm c-grey-600">

            <span class=" text-center">Copyright 2018 Designed by
                <a href="https://www.instagram.com/mertcorumlu/" target="_blank" title="Mert ÇORUMLU">Mert ÇORUMLU</a>.
                <br>
            All Rights Reserved.</span>



</footer>
</div>
</div>

<script src="/inc/js/javascript.js"></script>
<script type="text/javascript" src="/inc/js/sidebar.js"></script>
<script src="/inc/js/bootstrap-formhelpers.min.js"></script>
<script type="text/javascript" src="/inc/css/DataTables-1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/inc/css/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="/inc/css/Responsive-2.2.1/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="/inc/css/Responsive-2.2.1/js/responsive.bootstrap4.min.js"></script>




<?=$footer."\n"?>

</body>
</html>
